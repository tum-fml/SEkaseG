# Baumaschinen Konfigurator

## Übersicht
Ein Python-Programm zur Konfiguration von elektrischen Baumaschinen.

## Vorbereitung

### Installiere Python
1. **Python-Installation überprüfen**: Stelle sicher, dass Python auf deinem Computer installiert ist. Du kannst dies überprüfen, indem du `python --version` oder `python3 --version` in der Konsole eingibst.

2. **Falls Python nicht installiert ist**: Lade Python von der [offiziellen Website](https://www.python.org/downloads/) herunter und installiere es.

## Ausführen des Programms von einem USB-Stick

1. **Öffne die Eingabeaufforderung (CMD)**:
   - Auf Windows: Drücke `Win + R`, gib `cmd` ein und drücke `Enter`.
   - Auf MacOS oder Linux: Öffne das Terminal.

2. **Navigiere zum Verzeichnis des Konfigurators**:
   - Wechsle in das Verzeichnis des Konfigurators. Angenommen, er befindet sich auf Laufwerk `C:`
     ```bash
     C:
     cd Dependency Diagramm of Electrification Parameters\Configurator
     ```

3. **Starte das Programm**:
   - Führe das Skript aus:
     ```bash
     python main.py
     ```

   - Falls du `python` und `python3` installiert hast, kann es sein, dass du `python3` verwenden musst:
     ```bash
     python3 main.py
     ```

4. **Folge den Anweisungen im Programm**:
   - Das Programm wird dich durch die Konfiguration der Baumaschinen führen.

## Dateien als neuen Vault in Obsidian öffnen

1. **Obsidian installieren**:
   - Falls du Obsidian noch nicht installiert hast, lade es von der [offiziellen Website](https://obsidian.md/) herunter und installiere es.

2. **Neuen Vault erstellen**:
   - Öffne Obsidian und klicke auf `Open folder as vault`.
   - Navigiere zum Verzeichnis "Dependency Diagramm of Electrification Parameters\Configurator\Baumaschinen`.
   - Klicke auf `Open`.

3. **Dateien im Vault anzeigen**:
   - Die Dateien werden nun im neuen Vault in Obsidian angezeigt und können dort weiter bearbeitet werden.

## Lizenz
Dieses Projekt ist unter der MIT-Lizenz lizenziert.
