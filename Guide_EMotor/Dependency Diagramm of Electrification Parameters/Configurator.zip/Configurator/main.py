import os
import shutil

BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # Pfad zum Skript
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")  # Korrigiere den Vorlagen-Ordner
print(f"TEMPLATES_DIR: {TEMPLATES_DIR}")

def kopiere_vorlage(ziel_ordner, vorlage_name):
    quelle = os.path.join(TEMPLATES_DIR, vorlage_name)
    print(f"Überprüfe Quelle: {quelle}")
    if not os.path.exists(quelle):
        print(f"❌ Vorlage '{vorlage_name}' existiert nicht!")
        return
    shutil.copytree(quelle, os.path.join(ziel_ordner, vorlage_name), dirs_exist_ok=True)
    print(f"✔ {vorlage_name} wurde erfolgreich kopiert.")

def erstelle_komponente(ziel_ordner, anzahl, hv_anzahl, typ):
    for i in range(anzahl - hv_anzahl):
        dateipfad = os.path.join(ziel_ordner, f"{typ}_{i}_NV")
        quelle = os.path.join(TEMPLATES_DIR, f"{typ}_Template")
        print(f"Überprüfe Quelle: {quelle}")
        if not os.path.exists(quelle):
            print(f"❌ Vorlage '{typ}_Template' existiert nicht!")
            return
        shutil.copytree(quelle, dateipfad, dirs_exist_ok=True)
        print(f"✔ {typ} {i} NV erstellt: {dateipfad}")

    for i in range(hv_anzahl):
        dateipfad = os.path.join(ziel_ordner, f"{typ}_{i}_HV")
        quelle = os.path.join(TEMPLATES_DIR, f"{typ}_Template")
        if not os.path.exists(quelle):
            print(f"❌ Vorlage '{typ}_Template' existiert nicht!")
            return
        shutil.copytree(quelle, dateipfad, dirs_exist_ok=True)
        print(f"✔ {typ} {i} HV erstellt: {dateipfad}")

def main():
    print("Willkommen beim Baumaschinen-Konfigurator")
    name = input("Wie heißt Ihre neue Baumaschine?\n")

    # Zielordner erstellen
    ziel_ordner = os.path.join(BASE_DIR, "Baumaschinen", name)
    os.makedirs(ziel_ordner, exist_ok=True)
    print(f"✔ Projektordner erstellt: {ziel_ordner}")

    # Kopiere Basisvorlagen
    kopiere_vorlage(ziel_ordner, "Steuerung")
    kopiere_vorlage(ziel_ordner, "Gesamtsystem")

    netz_typ = input("Hat die Baumaschine HV, NV oder HVNV?\n").upper()
    if netz_typ == "HV":
        kopiere_vorlage(ziel_ordner, "Leistungselektronik_HV")
    elif netz_typ == "NV":
        kopiere_vorlage(ziel_ordner, "Leistungselektronik_NV")
    elif netz_typ == "HVNV":
        kopiere_vorlage(ziel_ordner, "Leistungselektronik_HV")
        kopiere_vorlage(ziel_ordner, "Leistungselektronik_NV")
    else:
        print("❌ Ungültige Eingabe!")
        return

    # Abfrage der Komponenten
    print("\nBatterien:")
    anzahl_batterien = int(input("Wie viele Batterien hat Ihre Baumaschine?\n"))
    hv_batterien = int(input("Wie viele Batterien davon sind HV?\n"))
    erstelle_komponente(ziel_ordner, anzahl_batterien, hv_batterien, "Batterie")

    print("\nElektromotoren:")
    anzahl_motoren = int(input("Wie viele Elektromotoren?\n"))
    hv_motoren = int(input("Wie viele Motoren davon sind HV?\n"))
    erstelle_komponente(ziel_ordner, anzahl_motoren, hv_motoren, "Elektromotor")

    print("\nNebenverbraucher:")
    anzahl_neben = int(input("Wie viele Nebenverbraucher?\n"))
    hv_neben = int(input("Wie viele davon sind HV?\n"))
    erstelle_komponente(ziel_ordner, anzahl_neben, hv_neben, "Nebenverbraucher")

    print(f"\n✔ Konfiguration abgeschlossen! Dateien befinden sich in: {ziel_ordner}")

if __name__ == "__main__":
    main()
