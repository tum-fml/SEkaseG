(alias Gesamtsystem)
#Gesamtsystem

Attribute:
[[Anschaffungskosten der Baumaschine]]
[[Betriebskosten des Gesamtsystems]]
[[Drehzahl und Lastdynamik des Gesamtsystems]]
[[Einsatzgewicht des Gesamtsystems]]
[[Einsatzzeit des Gesamtsystems]]
[[Lebensdauer des Gesamtsystems]]
[[Leistungsanpassungsfähigkeit des Gesamtsystems]]
[[Leistungsbedarf des Gesamtsystems]]
[[Nennleistung des Gesamtsystems]]
[[Packaging des Gesamtsystems]]
[[Sicherheitsanforderungen des Gesamtsystems]]
[[Thermomanagement des Gesamtsystems]]
[[Umweltanforderungen des Gesamtsystems]]

Bauteile:
[[Nebenverbraucher]]
[[Batterie]]
[[Elektromotor]]
[[Steuerung]]
[[Leistungselektronik]]
