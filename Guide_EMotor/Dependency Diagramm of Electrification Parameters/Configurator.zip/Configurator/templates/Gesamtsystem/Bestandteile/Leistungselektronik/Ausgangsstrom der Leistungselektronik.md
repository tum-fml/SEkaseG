#Leistungselektronik

[[Übersetzungsverhältnis der Leistungselektronik]]
[[Eingangsstrom der Leistungselektronik]]
[[Eingangsstromstärke des Elektromotors]]
[[Drehmoment - Drehzahlcharakteristik des Elektromotors]]