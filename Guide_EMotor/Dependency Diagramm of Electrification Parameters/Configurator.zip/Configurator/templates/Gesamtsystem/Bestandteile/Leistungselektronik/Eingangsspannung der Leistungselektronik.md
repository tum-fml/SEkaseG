#Leistungselektronik

[[Übersetzungsverhältnis der Leistungselektronik]]
[[Ausgangsspannung der Leistungselektronik]]

[[Lade- Entladekapazität der Batterie]]
[[SOC Ladezustand der Batterie]]