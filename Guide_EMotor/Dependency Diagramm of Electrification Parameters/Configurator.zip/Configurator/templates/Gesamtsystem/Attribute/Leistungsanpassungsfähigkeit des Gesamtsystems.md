#Gesamtsystem 

[[Kapazität der Batterie]] 
[[Nebenverbraucher]]
[[Drehzahl und Lastdynamik des Gesamtsystems]]
[[Betriebskosten des Gesamtsystems|Betriebskosten des Gesamtsystems]] 
[[Einsatzzeit des Gesamtsystems]]
[[Einsatzgewicht des Gesamtsystems]]
[[Anschaffungskosten der Baumaschine|Anschaffungskosten der Baumaschine]]
[[Packaging des Gesamtsystems|Packaging des Gesamtsystems]]