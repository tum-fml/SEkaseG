#Gesamtsystem 

 [[Kapazität der Batterie]] 
 [[SOC Ladezustand der Batterie]] 
[[Lebensdauer des Gesamtsystems|Lebensdauer des Gesamtsystems]] 
[[Leistungsanpassungsfähigkeit des Gesamtsystems]] 
[[Leistungsbedarf des Gesamtsystems]] 