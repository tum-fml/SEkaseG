#Gesamtsystem 

[[Gewicht der Batterie|Gewicht der Batterie]] 
[[Gewicht des Elektromotors|Gewicht des Elektromotors]]

 [[Anschaffungskosten der Baumaschine|Anschaffungskosten der Baumaschine]]
[[Nennleistung des Gesamtsystems]] 
[[Betriebskosten des Gesamtsystems|Betriebskosten des Gesamtsystems]] 
[[Leistungsanpassungsfähigkeit des Gesamtsystems]] 
