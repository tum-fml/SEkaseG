#Gesamtsystem 

[[Anschaffungskosten der Batterie]] 
[[Anschaffungskosten des Elektromotors]] 
[[Anschaffungskosten des Nebenverbrauchers]] 


[[Sicherheitsanforderungen des Gesamtsystems]]
[[Packaging des Gesamtsystems|Packaging des Gesamtsystems]]
[[Thermomanagement des Gesamtsystems]]
[[Lebensdauer des Gesamtsystems|Lebensdauer des Gesamtsystems]]
[[Nennleistung des Gesamtsystems]]
[[Einsatzgewicht des Gesamtsystems]]
[[Betriebskosten des Gesamtsystems|Betriebskosten des Gesamtsystems]]
[[Leistungsanpassungsfähigkeit des Gesamtsystems]]
[[Umweltanforderungen des Gesamtsystems]]