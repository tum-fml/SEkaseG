#Batterie 


 [[Lade- Entladekapazität der Batterie]]
 [[Eingangsspannung des Elektromotors]]
 [[Eingangsstrom der Leistungselektronik]]
 [[Verluste der Batterie]]
 [[Batterieanbindung HV]]