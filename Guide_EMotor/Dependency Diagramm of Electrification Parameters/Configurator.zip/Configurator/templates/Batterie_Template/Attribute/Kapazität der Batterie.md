#Batterie 

 [[Zellchemie der Batterie]]
 [[Anschaffungskosten der Batterie]]
 [[Batteriemodul]
 [[Gewicht der Batterie]]
 [[Temperatur der Batterie]]
 [[Leistungsanpassungsfähigkeit des Gesamtsystems]]
 [[Einsatzzeit des Gesamtsystems]]