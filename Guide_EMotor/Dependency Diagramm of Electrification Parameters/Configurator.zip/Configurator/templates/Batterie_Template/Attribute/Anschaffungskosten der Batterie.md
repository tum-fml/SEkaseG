#Batterie

[[Anschaffungskosten der Baumaschine]]
[[Kapazität der Batterie]]
[[Zellchemie der Batterie]]
