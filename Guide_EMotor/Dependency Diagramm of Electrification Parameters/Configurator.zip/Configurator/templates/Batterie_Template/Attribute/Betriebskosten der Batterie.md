#Batterie 

 [[Lebensdauer der Batterie|Lebensdauer der Batterie]] 
  [[Kapazität der Batterie]] 
  [[Betriebskosten des Gesamtsystems|Betriebskosten des Gesamtsystems]]