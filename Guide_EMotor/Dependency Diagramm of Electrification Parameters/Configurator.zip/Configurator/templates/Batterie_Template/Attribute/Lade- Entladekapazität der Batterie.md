#Batterie 

[[Lebensdauer der Batterie|Lebensdauer der Batterie]]
[[Verluste der Batterie]]
[[SOC Ladezustand der Batterie]] 
[[Hochspannungsinterface der Batterie]]
[[Eingangsspannung des Elektromotors]]
[[Eingangsstrom der Leistungselektronik]] 
[[elektrisches Interface der Steuerung]] 