#Elektromotor


[[Gehäuse des Elektromotors]]
[[Leiter des Elektromotors]]
[[Kühlung des Elektromotors]]
[[Rotor des Elektromotors]]
[[Stator des Elektromotors]]
[[Wicklung des Elektromotors]]


[[Einsatzgewicht des Gesamtsystems]]