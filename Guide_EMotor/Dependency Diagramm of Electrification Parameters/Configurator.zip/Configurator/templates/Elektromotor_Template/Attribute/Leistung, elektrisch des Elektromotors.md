#Elektromotor 

[[Eingangsstromstärke des Elektromotors]]
[[Eingangsspannung des Elektromotors]]
[[Verluste oder Wirkungsgrad des Elektromotors]]

[[Gehäuse des Elektromotors]]
[[Leiter des Elektromotors]]
[[Kühlung des Elektromotors]]
[[Rotor des Elektromotors]]
[[Stator des Elektromotors]]
[[Wicklung des Elektromotors]]