#Elektromotor

[[Verschleiß des Elektromotors]]
[[Lebensdauer des Elektromotors]]
[[Verluste oder Wirkungsgrad des Elektromotors]]
[[Thermomanagement des Elektromotors]]

[[Thermomanagement des Gesamtsystems]]