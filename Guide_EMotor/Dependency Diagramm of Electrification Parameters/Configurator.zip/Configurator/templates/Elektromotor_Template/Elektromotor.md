#Elektromotor

Attribute:
[[Anschaffungskosten des Elektromotors]]
[[Betriebsdauer des Elektromotors]]
[[Betriebskosten des Elektromotors]]
[[Gesamtsystem/Bestandteile/Elektromotor/Attribute/Drehmoment - Drehzahlcharakteristik des Elektromotors]]
[[Eingangsspannung des Elektromotors]]
[[Eingangsstromstärke des Elektromotors]]
[[Gewicht des Elektromotors]]
[[Lebensdauer des Elektromotors]]
[[Leistung des Elektromotors]]
[[Leistung, elektrisch des Elektromotors]]
[[Leistung, mechanisch des Elektromotors]]
[[Nennleistung des Elektromotors]]
[[Temperatur des Elektromotors]]
[[Thermomanagement des Elektromotors]]
[[Verluste oder Wirkungsgrad des Elektromotors]]
[[Verschleiß des Elektromotors]]

Anbindung:
[[Anbindung Elektromotor Hochvolt]]
[[Anbindung Elektromotor Niedervolt]]

Bestandteile:
[[Gehäuse des Elektromotors]]
[[Getriebe des Elektromotors]]
[[Kühlung des Elektromotors]]
[[Leiter des Elektromotors]]
[[Packaging des Elektromotors]]
[[Rotor des Elektromotors]]
[[Stator des Elektromotors]]
[[Wicklung des Elektromotors]]