#Elektromotor 

[[Stator des Elektromotors]]
[[Gehäuse des Elektromotors]]
[[Leiter des Elektromotors]]
[[Leistung, mechanisch des Elektromotors]]
[[Packaging des Elektromotors]]
[[Gewicht des Elektromotors]]
[[Wicklung des Elektromotors]]
[[Verschleiß des Elektromotors]]
[[Drehmoment - Drehzahlcharakteristik des Elektromotors]]
