#Elektromotor 

[[Rotor des Elektromotors]]
[[Gehäuse des Elektromotors]]
[[Leiter des Elektromotors]]
[[Packaging des Elektromotors]]
[[Wicklung des Elektromotors]]
[[Gewicht des Elektromotors]]
[[Verluste oder Wirkungsgrad des Elektromotors]]
[[Drehmoment - Drehzahlcharakteristik des Elektromotors]]
