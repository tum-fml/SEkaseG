#Elektromotor 

[[Niedervoltnetz]]