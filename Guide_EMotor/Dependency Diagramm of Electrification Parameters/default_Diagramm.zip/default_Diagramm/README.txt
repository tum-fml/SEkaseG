## Dateien als neuen Vault in Obsidian öffnen

1. **Obsidian installieren**:
   - Falls du Obsidian noch nicht installiert hast, lade es von der [offiziellen Website](https://obsidian.md/) herunter und installiere es.

2. **Neuen Vault erstellen**:
   - Öffne Obsidian und klicke auf `Open folder as vault`.
   - Navigiere zum Verzeichnis "Dependency Diagramm of Electrification Parameters\default_Diagramm\Dependency Diagramm`.
   - Klicke auf `Open`.

3. **Dateien im Vault anzeigen**:
   - Die Dateien werden nun im neuen Vault in Obsidian angezeigt und können dort weiter bearbeitet werden.

4. **default_Diagramm**:
   - umfasst: 1x HV-Netz, 1x HV-Batterie, 1x Elektromotor am HV, 0x Nebenverbraucher

5. **Abhängigkeitspfade identifizieren**
   - Ausgangspunkt wählen, z.B. "Elektromotor"
   - Rechtsklick --> "Lokalen Graph öffnen"
   - Filter: gewünschte Tiefe einstellen










## Lizenz
Dieses Projekt ist unter der MIT-Lizenz lizenziert.