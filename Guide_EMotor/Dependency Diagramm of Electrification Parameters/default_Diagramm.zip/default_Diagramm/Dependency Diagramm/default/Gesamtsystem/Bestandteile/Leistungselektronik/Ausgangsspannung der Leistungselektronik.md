#Leistungselektronik

[[Übersetzungsverhältnis der Leistungselektronik]]
[[Eingangsspannung der Leistungselektronik]]
[[Eingangsspannung des Elektromotors]]
[[Drehmoment - Drehzahlcharakteristik des Elektromotors]]
