#Leistungselektronik

[[Ausgangsstrom der Leistungselektronik]]
[[Übersetzungsverhältnis der Leistungselektronik]]


[[SOC Ladezustand der Batterie]]
[[Lade- Entladekapazität der Batterie]]
