 #Gesamtsystem 
 
 [[Temperatur der Batterie|Temperatur der Batterie]] 
[[Kühlung der Batterie|Kühlung der Batterie]] 
[[Informationsinterface der Steuerung]]
[[Temperatur des Elektromotors|Temperatur des Elektromotors]]
[[Packaging des Gesamtsystems|Packaging des Gesamtsystems]]
[[Lebensdauer des Gesamtsystems|Lebensdauer des Gesamtsystems]]
[[Anschaffungskosten der Baumaschine|Anschaffungskosten der Baumaschine]]