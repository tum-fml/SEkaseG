#Gesamtsystem 
 
 [[Lebensdauer der Batterie|Lebensdauer der Batterie]]

[[Betriebskosten des Nebenverbrauchers|Betriebskosten des Nebenverbrauchers]] 

[[Betriebskosten des Elektromotors|Betriebskosten des Elektromotors]] 