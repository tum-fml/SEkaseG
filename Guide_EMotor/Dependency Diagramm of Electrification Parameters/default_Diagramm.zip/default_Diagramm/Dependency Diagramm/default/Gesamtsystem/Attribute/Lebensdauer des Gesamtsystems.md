#Gesamtsystem 

 [[Lebensdauer der Batterie|Lebensdauer der Batterie]] 
 [[Lebensdauer des Elektromotors|Lebensdauer des Elektromotors]] 
 [[Lebensdauer der Leistungselektronik|Lebensdauer der Leistungselektronik]] 
 [[Thermomanagement des Gesamtsystems]]
  [[Einsatzzeit des Gesamtsystems]] 
[[Drehzahl und Lastdynamik des Gesamtsystems]]