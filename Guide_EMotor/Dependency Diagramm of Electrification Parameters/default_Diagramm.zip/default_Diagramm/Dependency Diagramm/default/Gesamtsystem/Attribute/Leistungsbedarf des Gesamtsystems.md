#Gesamtsystem 

 [[elektrisches Interface der Steuerung]]
 [[Nennleistung des Gesamtsystems]]
 [[Einsatzzeit des Gesamtsystems]]