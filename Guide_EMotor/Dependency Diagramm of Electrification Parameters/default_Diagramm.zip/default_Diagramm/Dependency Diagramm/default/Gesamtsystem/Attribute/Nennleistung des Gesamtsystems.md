#Gesamtsystem 

 [[Leistung des Elektromotors]] 
 [[Leistungsbedarf des Gesamtsystems]]
 [[Einsatzzeit des Gesamtsystems]]
 [[Drehzahl und Lastdynamik des Gesamtsystems]]
 [[Einsatzgewicht des Gesamtsystems]]