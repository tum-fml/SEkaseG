#Gesamtsystem 

 [[Human Machine Interface der Steuerung]]
 [[Packaging des Gesamtsystems]]
 [[Umweltanforderungen des Gesamtsystems]]
 [[Anschaffungskosten der Baumaschine]]