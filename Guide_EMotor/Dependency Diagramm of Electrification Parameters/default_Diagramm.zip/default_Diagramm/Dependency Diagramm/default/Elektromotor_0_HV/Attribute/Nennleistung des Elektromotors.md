#Elektromotor 

[[Verluste oder Wirkungsgrad des Elektromotors]]
[[Leistung, mechanisch des Elektromotors]]
[[Drehmoment - Drehzahlcharakteristik des Elektromotors]]
[[Thermomanagement des Elektromotors]]
