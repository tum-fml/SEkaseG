#Elektromotor 

[[Lebensdauer des Elektromotors]]
[[Temperatur des Elektromotors]]
[[Nennleistung des Elektromotors]]
[[Kühlung des Elektromotors]]
[[Anschaffungskosten des Elektromotors]]

[[Thermomanagement des Gesamtsystems]]