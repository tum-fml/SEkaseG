#Elektromotor 

[[Verluste oder Wirkungsgrad des Elektromotors]]
[[Betriebsdauer des Elektromotors]]
[[Temperatur des Elektromotors]]
[[Lebensdauer des Elektromotors]]

[[Betriebskosten des Gesamtsystems]]
