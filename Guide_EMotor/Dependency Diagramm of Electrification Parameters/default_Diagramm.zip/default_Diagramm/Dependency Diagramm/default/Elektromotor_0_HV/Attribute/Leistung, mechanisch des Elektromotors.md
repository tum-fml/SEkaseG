#Elektromotor 

[[Rotor des Elektromotors]]
[[Nennleistung des Elektromotors]]
[[Verluste oder Wirkungsgrad des Elektromotors]]
[[Wicklung des Elektromotors]]