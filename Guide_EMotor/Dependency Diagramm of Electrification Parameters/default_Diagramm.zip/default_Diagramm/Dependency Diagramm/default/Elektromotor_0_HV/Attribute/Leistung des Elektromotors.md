#Elektromotor


[[Nennleistung des Elektromotors]]
[[Leistung, mechanisch des Elektromotors]]
[[Leistung, elektrisch des Elektromotors]]