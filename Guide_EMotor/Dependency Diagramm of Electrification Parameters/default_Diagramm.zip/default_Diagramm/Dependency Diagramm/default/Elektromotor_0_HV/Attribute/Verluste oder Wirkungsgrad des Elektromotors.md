#Elektromotor 

[[Nennleistung des Elektromotors]]
[[Temperatur des Elektromotors]]
[[Verschleiß des Elektromotors]]
[[Wicklung des Elektromotors]]
[[Leistung, elektrisch des Elektromotors]]
[[Leistung, mechanisch des Elektromotors]]

[[Betriebskosten des Gesamtsystems]]
[[SOC Ladezustand der Batterie]]