#Elektromotor

[[Betriebsdauer des Elektromotors]]
[[Verschleiß des Elektromotors]]
[[Temperatur des Elektromotors]]
[[Thermomanagement des Elektromotors]]
[[Anschaffungskosten des Elektromotors]]

[[Lebensdauer des Gesamtsystems]]