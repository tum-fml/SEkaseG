#Elektromotor 


[[Gehäuse des Elektromotors]]
[[Leiter des Elektromotors]]
[[Kühlung des Elektromotors|Kühlung des Elektromotors]]
[[Rotor des Elektromotors]] 
[[Stator des Elektromotors]] 
[[Getriebe des Elektromotors]] 
[[Kühlung des Elektromotors|Kühlung des Elektromotors]]
[[Lebensdauer des Elektromotors|Lebensdauer des Elektromotors]] 
[[Anschaffungskosten der Baumaschine|Anschaffungskosten der Baumaschine]] 
[[Gewicht der Batterie|Gewicht der Batterie]]
[[Thermomanagement des Gesamtsystems|Thermomanagement des Gesamtsystems]]