#Elektromotor

[[Betriebskosten des Gesamtsystems]]

[[Lebensdauer des Elektromotors]]
[[Betriebsdauer des Elektromotors]]
[[Verschleiß des Elektromotors]]
[[Verluste oder Wirkungsgrad des Elektromotors]]
[[Anschaffungskosten des Elektromotors]]