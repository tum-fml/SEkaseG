#Elektromotor 

[[Anschaffungskosten des Elektromotors]]
[[Drehmoment - Drehzahlcharakteristik des Elektromotors]]
[[Gewicht des Elektromotors]]
[[Leistung, mechanisch des Elektromotors]]
[[Lebensdauer des Elektromotors]]
[[Verschleiß des Elektromotors]]
[[Verluste oder Wirkungsgrad des Elektromotors]]
[[Packaging des Elektromotors]]