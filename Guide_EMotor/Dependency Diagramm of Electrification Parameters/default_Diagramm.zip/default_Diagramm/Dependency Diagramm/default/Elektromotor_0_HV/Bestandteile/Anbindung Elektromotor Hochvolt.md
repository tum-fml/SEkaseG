#Elektromotor 
[[Hochvolt-Netz]]