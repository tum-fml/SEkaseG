#Elektromotor 

[[Rotor des Elektromotors]]
[[Stator des Elektromotors]]
[[Gehäuse des Elektromotors]]
[[Kühlung der Batterie]]
[[Wicklung des Elektromotors]]
[[Gewicht des Elektromotors]]
[[Verluste oder Wirkungsgrad des Elektromotors]]
[[Verschleiß des Elektromotors]]
[[Anschaffungskosten des Elektromotors]]
[[Packaging des Elektromotors]]