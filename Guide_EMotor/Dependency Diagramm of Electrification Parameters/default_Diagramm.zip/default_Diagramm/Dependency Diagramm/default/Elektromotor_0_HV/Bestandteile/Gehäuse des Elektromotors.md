#Elektromotor 

[[Leiter des Elektromotors]]
[[Kühlung des Elektromotors]]
[[Rotor des Elektromotors]]
[[Stator des Elektromotors]]
[[Anschaffungskosten des Elektromotors]]
[[Gewicht des Elektromotors]]
[[Packaging des Elektromotors]]