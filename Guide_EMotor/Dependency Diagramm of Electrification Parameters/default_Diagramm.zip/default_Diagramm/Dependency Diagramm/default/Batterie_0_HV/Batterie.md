#Batterie 

Attribute: 
[[Anschaffungskosten der Batterie]]
[[Batteriespannung]]
[[Betriebskosten der Batterie]]
[[interner Widerstand der Batterie]]
[[Kapazität der Batterie]]
[[Lade- Entladekapazität der Batterie]]
[[Lebensdauer der Batterie]]
[[Packaging der Batterie]]
[[SOC Ladezustand der Batterie]]
[[Temperatur der Batterie]]
[[Verluste der Batterie]]
[[Zellchemie der Batterie]]
Anbindung:
[[Batterieanbindung HV]]
[[Batterieanbindung Niedervoltnetz]]
Bestandteile:
[[Batterie-Management-System]]
[[Batteriecontroller]]
[[Batteriemodul]]
[[Batteriezelle]]
[[Hochspannungsinterface der Batterie]]
[[Kühlung der Batterie]]
[[Zellcontroller]]
