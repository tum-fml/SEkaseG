#Batterie

[[Verluste der Batterie]]
[[Lade- Entladekapazität der Batterie]]
[[Batteriespannung]] 
[[Verluste oder Wirkungsgrad des Elektromotors]]
[[Betriebsart des Nebenverbrauchers]]
[[Eingangsspannung des Elektromotors]]
[[Eingangsstrom der Leistungselektronik]]
[[Einsatzzeit des Gesamtsystems]] 