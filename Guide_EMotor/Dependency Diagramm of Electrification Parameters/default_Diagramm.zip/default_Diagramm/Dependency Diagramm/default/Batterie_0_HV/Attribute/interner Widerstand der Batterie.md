#Batterie 

[[Temperatur der Batterie]]
[[Verluste der Batterie]]
