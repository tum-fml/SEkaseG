#Batterie 

 [[Temperatur der Batterie|Temperatur der Batterie]]
 [[Batteriecontroller]]
 [[Zellchemie der Batterie]]
 [[Betriebskosten der Batterie|Betriebskosten der Batterie]]
 [[Lade- Entladekapazität der Batterie]] 
 [[Betriebskosten des Elektromotors|Betriebskosten des Elektromotors]]