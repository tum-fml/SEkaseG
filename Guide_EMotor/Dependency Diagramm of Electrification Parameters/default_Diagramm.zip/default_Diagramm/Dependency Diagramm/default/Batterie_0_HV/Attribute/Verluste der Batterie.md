#Batterie

 [[SOC Ladezustand der Batterie]] 
 [[Lade- Entladekapazität der Batterie]]
 [[interner Widerstand der Batterie]]
 